Copy cscope.exe to codeblocks bin directory:

C:\Dev\CodeBlocks\bin\